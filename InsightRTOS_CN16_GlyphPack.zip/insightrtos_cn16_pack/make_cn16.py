from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math, re, textwrap
base=Path(__file__).parent
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
# Explicitly bounded UI vocabulary; no full CJK font is embedded.
phrases=[
'系统运行','任务状态','按键','控制','显示','监控','就绪','阻塞','退出','未知','异常','死锁诊断','无死锁',
'存在循环','等待超时','诊断异常','快照失效','未启用','未检测','锁持有','等待者','优先级继承',
'错误计数','事件记录','单击','双击','长按','选中任务','最近事件','采样时刻','运行次数',
'正常','当前','内核节拍','刷新','暂停','告警','失败','成功','时钟','就绪','检查','选定','变更','短按',
'实时性','截止时间','预算超限','执行耗时','延迟','时序','唤醒','调度','状态','错误','重置','未测量','查询','有锁','超时','完成'
]
chars=''.join(dict.fromkeys(''.join(phrases)))
# Generate 16x16 bitmaps, row-major, LSB first within each byte, two bytes per row.
font=ImageFont.truetype(font_path, 17, index=2)
entries=[]
for char in chars:
    canvas=Image.new('L',(36,36),0)
    draw=ImageDraw.Draw(canvas)
    draw.text((18,18),char,font=font,fill=255,anchor='mm')
    bbox=canvas.getbbox()
    if not bbox: raise RuntimeError('missing '+char)
    glyph=canvas.crop(bbox)
    gw,gh=glyph.size
    if gw>15 or gh>15:
        scale=min(15/gw,15/gh)
        glyph=glyph.resize((max(1,round(gw*scale)),max(1,round(gh*scale))),resample=Image.Resampling.LANCZOS)
    final=Image.new('L',(16,16),0)
    final.paste(glyph,((16-glyph.width)//2,(16-glyph.height)//2))
    pix=final.point(lambda v:255 if v>=100 else 0)
    packed=[]
    for y in range(16):
        for b in (0,1):
            byte=sum( (1<<bit) if pix.getpixel((b*8+bit,y)) else 0 for bit in range(8))
            packed.append(byte)
    if len(packed)!=32: raise RuntimeError()
    entries.append((char,ord(char),packed,pix))

h='''#ifndef INSIGHT_LCD_CN16_H
#define INSIGHT_LCD_CN16_H

#include <stdint.h>
#include "st7789.h"

/* Tiny fixed Chinese font: 16x16 pixels, 1 bpp, 32 bytes/glyph.
   Built for UI-only subset. No dynamic memory or Unicode font files required.
   Call only from the LCD-owning task (same contract as LCD_ShowPicture). */
LCD_Result LCD_CN16_DrawGlyph(LCD_Device *dev, uint16_t x, uint16_t y,
                             uint32_t codepoint, uint16_t foreground, uint16_t background);
/* Draws mixed UTF-8 Chinese and 8x16 ASCII at same baseline.
   Invalid UTF-8 is drawn as '?' ASCII. Unsupported Chinese glyph is '??' ASCII.
   Output must remain within display bounds; returns first LCD error. */
LCD_Result LCD_CN16_ShowText(LCD_Device *dev, uint16_t x, uint16_t y,
                            const char *utf8, uint16_t foreground, uint16_t background);
uint32_t LCD_CN16_GlyphCount(void);

#endif
'''
(base/'lcd_cn16.h').write_text(h,encoding='utf-8')

c=['#include "lcd_cn16.h"','#include "lcd_fonts.h"','#include <stddef.h>','',
   '/* Generated, bounded 16x16 CJK subset from Noto Sans CJK SC (SIL OFL 1.1).',
   ' * Source bit layout matches legacy PCtoLCD C51: horizontal row-major,',
   ' * low bit first, 2 bytes per scanline, 32 bytes per glyph.',
   ' * Glyphs are embedded bitmaps only; no font file is shipped.',
   ' */',
   'typedef struct { uint16_t unicode; uint8_t bits[32]; } cn16_glyph_t;',
   'static const cn16_glyph_t cn16_glyphs[] = {']
for char,cp,pix,_ in entries:
    c.append(f'    /* {char} U+{cp:04X} */ {{0x{cp:04X}U, {{{", ".join(f"0x{v:02X}" for v in pix)}}}}},')
c+=['};','',
'static const uint8_t *cn16_lookup(uint32_t cp)',
'{',
'    for (size_t i = 0U; i < sizeof(cn16_glyphs) / sizeof(cn16_glyphs[0]); ++i) {',
'        if (cn16_glyphs[i].unicode == cp) return cn16_glyphs[i].bits;',
'    }',
'    return NULL;',
'}',
'',
'uint32_t LCD_CN16_GlyphCount(void)',
'{',
'    return (uint32_t)(sizeof(cn16_glyphs) / sizeof(cn16_glyphs[0]));',
'}',
'',
'LCD_Result LCD_CN16_DrawGlyph(LCD_Device *dev, uint16_t x, uint16_t y,',
'                             uint32_t codepoint, uint16_t foreground, uint16_t background)',
'{',
'    if (dev == NULL) return LCD_ERROR_PARAM;',
'    if ((uint32_t)x + 16U > dev->width || (uint32_t)y + 16U > dev->height)',
'        return LCD_ERROR_PARAM;',
'    const uint8_t *bits = cn16_lookup(codepoint);',
'    if (bits == NULL) return LCD_ERROR_PARAM;',
'    /* LCD_ShowPicture requires 16*16*2 big-endian RGB565 bytes.',
'     * This buffer is single-owner LCD Task only, no shared concurrent callers. */',
'    static uint8_t pixels[16U * 16U * 2U];',
'    for (uint32_t row = 0U; row < 16U; ++row) {',
'        for (uint32_t col = 0U; col < 16U; ++col) {',
'            const uint8_t bit = (uint8_t)(1U << (col & 7U));',
'            const uint16_t color = (bits[row * 2U + (col >> 3U)] & bit)',
'                                  ? foreground : background;',
'            const uint32_t offset = (row * 16U + col) * 2U;',
'            pixels[offset] = (uint8_t)(color >> 8U);',
'            pixels[offset + 1U] = (uint8_t)color;',
'        }',
'    }',
'    return LCD_ShowPicture(dev, x, y, 16U, 16U, pixels);',
'}',
'',
'LCD_Result LCD_CN16_ShowText(LCD_Device *dev, uint16_t x, uint16_t y,',
'                            const char *utf8, uint16_t foreground, uint16_t background)',
'{',
'    if (dev == NULL || utf8 == NULL || (uint32_t)y + 16U > dev->height)',
'        return LCD_ERROR_PARAM;',
'    const uint8_t *p = (const uint8_t *)utf8;',
'    while (*p != 0U) {',
'        if (*p < 0x80U) {',
'            if ((uint32_t)x + 8U > dev->width) return LCD_ERROR_PARAM;',
'            const uint8_t ch = (*p >= 32U && *p <= 126U) ? *p : (uint8_t)\'?\';',
'            const LCD_Result s = LCD_ShowChar(dev, x, y, ch, &ASCII_Font16, foreground, background);',
'            if (s != LCD_OK) return s;',
'            x = (uint16_t)(x + 8U);',
'            ++p;',
'            continue;',
'        }',
'        uint32_t cp = 0U;',
'        uint32_t used = 1U;',
'        /* UI font targets only valid 3-byte UTF-8 CJK characters. */',
'        if (p[0] >= 0xE0U && p[0] <= 0xEFU && p[1] != 0U && p[2] != 0U &&',
'            (p[1] & 0xC0U) == 0x80U && (p[2] & 0xC0U) == 0x80U) {',
'            cp = ((uint32_t)(p[0] & 0x0FU) << 12U) |',
'                 ((uint32_t)(p[1] & 0x3FU) << 6U) | (uint32_t)(p[2] & 0x3FU);',
'            used = 3U;',
'        }',
'        if (cn16_lookup(cp) != NULL) {',
'            if ((uint32_t)x + 16U > dev->width) return LCD_ERROR_PARAM;',
'            const LCD_Result s = LCD_CN16_DrawGlyph(dev, x, y, cp, foreground, background);',
'            if (s != LCD_OK) return s;',
'            x = (uint16_t)(x + 16U);',
'        } else {',
'            /* Unknown glyph uses a single ASCII question mark, no accidental raw UTF-8. */',
'            if ((uint32_t)x + 8U > dev->width) return LCD_ERROR_PARAM;',
'            const LCD_Result s = LCD_ShowChar(dev, x, y, (uint8_t)\'?\', &ASCII_Font16, foreground, background);',
'            if (s != LCD_OK) return s;',
'            x = (uint16_t)(x + 8U);',
'        }',
'        p += used;',
'    }',
'    return LCD_OK;',
'}']
(base/'lcd_cn16.c').write_text('\n'.join(c)+'\n',encoding='utf-8')

# Visual verification - every glyph reconstructed from packed binary, not from font raster.
from PIL import Image as IM, ImageDraw as ID
cols=12; scale=3; cell=58; rows=math.ceil(len(entries)/cols)
atlas=IM.new('RGB',(cols*cell,rows*cell),'white')
d=ID.Draw(atlas)
for i,(char,cp,packed,source) in enumerate(entries):
    tx=(i%cols)*cell; ty=(i//cols)*cell
    for y in range(16):
        for x in range(16):
            on=packed[y*2+x//8]>> (x%8) &1
            if on:d.rectangle((tx+x*scale,ty+y*scale,tx+x*scale+scale-1,ty+y*scale+scale-1), fill='black')
    d.text((tx+2,ty+48),char,font=ImageFont.truetype(font_path,10,index=2),fill='black')
atlas.save(base/'cn16_atlas_preview.png')

# Demo 240x240 render, rendered using packed glyph bitmaps + ASCII font from PIL to convey layout only
img=IM.new('RGB',(240,240),(9,23,36));d=ID.Draw(img)
d.rectangle((0,0,239,28),fill=(20,49,74));
f14=ImageFont.truetype(font_path,14,index=2); fa=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',11)
d.text((8,5),'InsightRTOS',font=fa,fill='white')
d.text((128,5),'系统运行',font=f14,fill='#86efac')
sections=[(33,'任务状态', '#facc15'),(125,'诊断状态','#facc15'),(181,'按键事件','#facc15')]
for y,t,color in sections:
    d.text((8,y),t,font=f14,fill=color)
    d.line((8,y+18,232,y+18), fill=(44,73,98), width=1)
for y,task,state,prio in [(55,'KEY','阻塞','P5'),(72,'CTRL','就绪','P4'),(89,'LCD','运行','P2'),(106,'MON','阻塞','P1')]:
    d.text((13,y),task,font=fa,fill='white');d.text((84,y),state,font=f14,fill='#8bdcfb');d.text((192,y),prio,font=fa,fill='white')
d.text((12,148),'无死锁',font=f14,fill='#8beaac')
d.text((107,151),'TRACE 128',font=fa,fill='white')
d.text((12,165),'错误 0',font=f14,fill='white')
d.text((12,200),'单击:选任务',font=f14,fill='white')
d.text((12,218),'双击:详情  长按:',font=ImageFont.truetype(font_path,12,index=2),fill='white'); d.text((183,220),'LED',font=fa,fill='white')
img.save(base/'dashboard_240_preview.png')
readme=f'''# InsightRTOS small Chinese bitmap font pack\n\n- {len(entries)} dedicated CJK glyphs, 16x16 pixels, 1 bpp.\n- Binary layout: 2 bytes per row, low-bit first, 32 bytes per glyph, compatible with the existing lcd_fonts.c row bit convention.\n- Source font used to rasterize the glyphs: Noto Sans CJK SC Regular (SIL Open Font License 1.1). No font file is shipped.\n- Files `lcd_cn16.c`, `lcd_cn16.h` are C11 standalone source; add to board BSP compilation, not RTOS kernel.\n- Uses `LCD_ShowPicture()` to write one RGB565 glyph as a burst; 512B static staging buffer; intended to run only from LCD owning task. No full frame buffer.\n- UTF-8 Chinese text via `LCD_CN16_ShowText()`, ASCII via already installed `ASCII_Font16`. Unsupported CJK renders `?`, no silent disappearance.\n- Example: `LCD_CN16_ShowText(&g_lcd, 8, 44, "任务状态", WHITE, BLACK);`\n- `cn16_atlas_preview.png` is decoded from *packed* C data for visual inspection. `dashboard_240_preview.png` is only a concept preview, not an actual board screenshot.\n- Existing `lcd_fonts.c` has several small Chinese glyph arrays, but the current driver only exposes ASCII ShowString; this pack provides a bounded UTF-8 display path.\n- Rendering implications: use 16 px for Chinese, 8 px for ASCII at 16 px height, avoid overflowing 240 px.\n- The bundled PNG is not a substitute for checking the actual ST7789 panel.\n\nGlyph set: `{chars}`\n'''
(base/'README.md').write_text(readme,encoding='utf-8')
print('GLYPHS',len(entries),'SIZE',len((base/'lcd_cn16.c').read_bytes()),'atlas',atlas.size)

# InsightRTOS small Chinese bitmap font pack

- 118 dedicated CJK glyphs, 16x16 pixels, 1 bpp.
- Binary layout: 2 bytes per row, low-bit first, 32 bytes per glyph, compatible with the existing lcd_fonts.c row bit convention.
- Source font used to rasterize the glyphs: Noto Sans CJK SC Regular (SIL Open Font License 1.1). No font file is shipped.
- Files `lcd_cn16.c`, `lcd_cn16.h` are C11 standalone source; add to board BSP compilation, not RTOS kernel.
- Uses `LCD_ShowPicture()` to write one RGB565 glyph as a burst; 512B static staging buffer; intended to run only from LCD owning task. No full frame buffer.
- UTF-8 Chinese text via `LCD_CN16_ShowText()`, ASCII via already installed `ASCII_Font16`. Unsupported CJK renders `?`, no silent disappearance.
- Example: `LCD_CN16_ShowText(&g_lcd, 8, 44, "任务状态", WHITE, BLACK);`
- `cn16_atlas_preview.png` is decoded from *packed* C data for visual inspection. `dashboard_240_preview.png` is only a concept preview, not an actual board screenshot.
- Existing `lcd_fonts.c` has several small Chinese glyph arrays, but the current driver only exposes ASCII ShowString; this pack provides a bounded UTF-8 display path.
- Rendering implications: use 16 px for Chinese, 8 px for ASCII at 16 px height, avoid overflowing 240 px.
- The bundled PNG is not a substitute for checking the actual ST7789 panel.

Glyph set: `系统运行任务状态按键控制显示监就绪阻塞退出未知异常死锁诊断无存在循环等待超时快照失效启用检测持有者优先级继承错误计数事件记录单击双长选中最近采样刻次正当前内核节拍刷新暂停告警败成功钟查定变更短实性截止间预算限执耗延迟序唤醒调度重置量询完`

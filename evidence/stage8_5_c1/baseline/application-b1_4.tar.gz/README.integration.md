# ST7789 + InsightRTOS 四任务应用

这是B1冻结显示工程的本仓库独立快照，保留原裸机与双任务目标；新目标insightrtos_display，默认不开启四任务。生产内核的内容清单见Middlewares/InsightRTOS/VERSION_MANIFEST.md，原应用冻结与本轮变更见../../evidence/stage8_5_b1_4。

在此目录执行：

```sh
cmake --preset DISPLAY_RTOS_Debug
cmake --build --preset DISPLAY_RTOS_Debug
cmake --preset DISPLAY_RTOS_O2
cmake --build --preset DISPLAY_RTOS_O2
```

需要PATH中已有arm-none-eabi工具链、CMake>=3.22、Ninja。每个preset使用单独build目录。Debug/O2保留原裸机；RTOS_Debug/RTOS_O2保留B1双任务；DISPLAY_RTOS_Debug/DISPLAY_RTOS_O2为四任务。绝不因构建触发下载/擦除/复位。

新代码Core/display_app.c/h、display_pages.c、display_policy.c；只在INSIGHT_DISPLAY_RTOS分支改变key_port事件接口与TIM2/任务延时。原页面C文件由adapter包含一次，RTOS目标不再单独编译，裸机目标照常单独编译。没有动态内存或外部源码依赖。

四任务的实际显示、频率、稳定性尚未硬件验收。请先审阅evidence和artifacts/stage8_5_b1_4，不自动烧录。

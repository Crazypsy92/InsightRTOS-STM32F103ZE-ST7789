/* Compile the unchanged legacy page translation unit exactly once.
 * This adapter is the only owner of its private render state. */
#include "display_app.h"
#include "../BSP/Src/app_lcd_test.c"

static key_event_t staged_event;
static uint32_t staged_consumptions;
static uint32_t refresh_count;

key_event_t Display_ConsumeKeyEvent(void)
{
    Display_RequireLCDTask();
    const key_event_t value = staged_event;
    staged_event = KEY_EVENT_NONE;
    ++staged_consumptions;
    return value;
}

static void snapshot(uint32_t sequence, display_ack_t *ack)
{
    ack->sequence=sequence; ack->page=s_page; ack->automatic=s_auto_run;
    ack->ready=s_ready; ack->page_started_ms=s_page_start_ms;
    ack->frame_ms=s_last_frame_ms; ack->error=(int32_t)LCD_GetLastError(&g_lcd);
    ack->refreshes=refresh_count;
}
void Display_PagesInit(display_ack_t *ack)
{
    Display_RequireLCDTask();
    staged_event=KEY_EVENT_NONE;
    LCD_Test_Init();
    if (s_ready != 0U) ++refresh_count;
    snapshot(0U,ack);
}
void Display_PagesExecute(const display_command_t *cmd, display_ack_t *ack)
{
    Display_RequireLCDTask();
    RTOS_ASSERT(s_ready != 0U);
    RTOS_ASSERT(staged_event == KEY_EVENT_NONE);
    const uint32_t before=staged_consumptions;
    const uint32_t old_page=s_page, old_frame=s_last_frame_ms;
    LCD_ClearError(&g_lcd); /* Previous command error is already in its ACK. */
    staged_event=(key_event_t)cmd->event;
    LCD_Test_Task(); /* Original sole KEY_GetEvent consumer; no page rewrite. */
    RTOS_ASSERT(staged_consumptions == before+1U);
    RTOS_ASSERT(staged_event == KEY_EVENT_NONE);
    if (old_page!=s_page || old_frame!=s_last_frame_ms) ++refresh_count;
    snapshot(cmd->sequence,ack);
}

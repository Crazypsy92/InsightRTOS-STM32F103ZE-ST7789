#include "display_app.h"
bool Display_UpdateDue(uint32_t now, uint32_t page, uint32_t automatic,
                       uint32_t page_started, uint32_t frame_started)
{
    return (automatic != 0U && page < 3U && (uint32_t)(now-page_started) >= 2000U)
        || (page == 3U && (uint32_t)(now-frame_started) >= 25U);
}

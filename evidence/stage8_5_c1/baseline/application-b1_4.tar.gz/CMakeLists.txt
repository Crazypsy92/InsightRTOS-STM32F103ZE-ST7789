cmake_minimum_required(VERSION 3.22)

#
# This file is generated only once,
# and is not re-generated if converter is called multiple times.
#
# User is free to modify the file as much as necessary
#

# Setup compiler settings
set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS ON)


# Define the build type
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE "Debug")
endif()

# Set the project name
option(INSIGHT_DISPLAY_RTOS "Build the original four-page RTOS application" OFF)
option(INSIGHT_RTOS_ENABLED "Build the isolated dual-task RTOS smoke image" OFF)
if(INSIGHT_RTOS_ENABLED)
    if(INSIGHT_DISPLAY_RTOS)
        set(CMAKE_PROJECT_NAME insightrtos_display)
    else()
        set(CMAKE_PROJECT_NAME insightrtos_rtos)
    endif()
else()
    set(CMAKE_PROJECT_NAME insightrtos)
endif()

# Enable compile command to ease indexing with e.g. clangd
set(CMAKE_EXPORT_COMPILE_COMMANDS TRUE)

# Core project settings
project(${CMAKE_PROJECT_NAME})
message("Build type: " ${CMAKE_BUILD_TYPE})

# Enable CMake support for ASM and C languages
enable_language(C ASM)

# Create an executable object type
add_executable(${CMAKE_PROJECT_NAME})

# Add STM32CubeMX generated sources
add_subdirectory(cmake/stm32cubemx)

# Link directories setup
target_link_directories(${CMAKE_PROJECT_NAME} PRIVATE
    # Add user defined library search paths
)

# Add sources to executable
target_sources(${CMAKE_PROJECT_NAME} PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/key_port.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/multi_button.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/delay.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/spi_stm32_ll.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/bsp_spi.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/st7789.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/st7789_port.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/lcd_fonts.c
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Src/app_lcd_test.c
)

# Add include paths
target_include_directories(${CMAKE_PROJECT_NAME} PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/BSP/Inc
)

# Add project symbols (macros)
target_compile_definitions(${CMAKE_PROJECT_NAME} PRIVATE
    # Add user defined symbols
)

# Remove wrong libob.a library dependency when using cpp files
list(REMOVE_ITEM CMAKE_C_IMPLICIT_LINK_LIBRARIES ob)

# Add linked libraries
target_link_libraries(${CMAKE_PROJECT_NAME}
    stm32cubemx

    # Add user defined libraries
)

if(INSIGHT_RTOS_ENABLED)
    include(cmake/insight_rtos.cmake)
endif()
add_custom_command(TARGET ${CMAKE_PROJECT_NAME} POST_BUILD
    COMMAND ${CMAKE_OBJCOPY} -O binary $<TARGET_FILE:${CMAKE_PROJECT_NAME}>
        ${CMAKE_CURRENT_BINARY_DIR}/${CMAKE_PROJECT_NAME}.bin
    VERBATIM)

if(INSIGHT_DISPLAY_RTOS)
    get_target_property(display_sources ${CMAKE_PROJECT_NAME} SOURCES)
    list(FILTER display_sources EXCLUDE REGEX "/(rtos_smoke_app|app_lcd_test)[.]c$")
    set_property(TARGET ${CMAKE_PROJECT_NAME} PROPERTY SOURCES "${display_sources}")
    target_sources(${CMAKE_PROJECT_NAME} PRIVATE Core/display_app.c Core/display_pages.c Core/display_policy.c)
    target_compile_definitions(${CMAKE_PROJECT_NAME} PRIVATE INSIGHT_DISPLAY_RTOS=1)
    set_source_files_properties(Core/display_pages.c PROPERTIES COMPILE_OPTIONS "-fno-inline")
endif()

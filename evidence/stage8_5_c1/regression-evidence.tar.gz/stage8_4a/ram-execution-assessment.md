# RAM-only execution assessment; NO load/run performed

| Image | Code+static+MSP lower bound B | 64KiB arithmetic | RAM execution decision |
| --- | ---: | --- | --- |
| debug-off-b1 | 62328 | fits lower bound only | rejected/not authorized |
| debug-off-b2 | 71328 | exceeds | rejected/not authorized |
| debug-off-b3 | 74200 | exceeds | rejected/not authorized |
| debug-off-b4 | 74096 | exceeds | rejected/not authorized |
| debug-on-b1 | 66728 | exceeds | rejected/not authorized |
| debug-on-b2 | 75696 | exceeds | rejected/not authorized |
| debug-on-b3 | 78568 | exceeds | rejected/not authorized |
| debug-on-b4 | 78496 | exceeds | rejected/not authorized |
| o2-off-b1 | 51072 | fits lower bound only | rejected/not authorized |
| o2-off-b2 | 59072 | fits lower bound only | rejected/not authorized |
| o2-off-b3 | 63704 | fits lower bound only | rejected/not authorized |
| o2-off-b4 | 63024 | fits lower bound only | rejected/not authorized |
| o2-on-b1 | 55352 | fits lower bound only | rejected/not authorized |
| o2-on-b2 | 63360 | fits lower bound only | rejected/not authorized |
| o2-on-b3 | 67992 | exceeds | rejected/not authorized |
| o2-on-b4 | 67320 | exceeds | rejected/not authorized |

Code/constants/data must coexist with32KiB user stacks, kernel data/Idle and4KiB MSP. This lower
bound removes the Flash .data initializer copy to avoid counting .data twice, and omits extra
relocation/vector/emergency-stack requirements; it is an optimistic screening estimate, not a
valid RAM ELF layout. Near-limit/over-limit images are rejected;
even a smaller B1 lacks a reviewed RAM linker/VTOR/entry/restore protocol. No stack shrinking or
SRAM write accepted. Full B1–B4 RAM execution is not a deployment option for this stage.
Only Flash-backed independent-board images are prepared; no inference that current-board Flash
may be overwritten. Pausing/replacing RAM changes current state even without Flash writes.

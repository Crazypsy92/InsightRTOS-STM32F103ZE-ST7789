# B1～B4 未来硬件验收流程（本轮不执行）

首先完成授权清单，选择明确可用于独立冷启动的实验板并记录实物身份；
当前已装固件板仍HARDWARE_INSTALLATION_BLOCKED，不接受“随便用同一块板”作为覆盖授权。
每次实验记录主机/驱动/探针序列号、板版本/芯片型号、连线/电压/供电、BOOT引脚、
工具版本、profile、ELF/BIN/MAP SHA与vector起点。独立板需确认主Flash启动配置，
不能将0x08009400 APP的BIN当作冷启动文件。

后续授权必须分别覆盖连接、halt/reset、读备份、具体地址写入、执行、恢复等操作。
本轮没有提供一键连接或写入脚本。GDB observation.gdb.in只是在已授权、已手动停机的会话中
读取寄存器/内存的模板，无target/load/continue/reset命令；单独UART PASS不构成验收。

| 层次 | 有界场景和双重证据 | 尚需的硬件补充 |
| --- | --- | --- |
| B1 | 冷启动一次，Reset断点、向量76项/MSP、.data哨兵/.bss零、RCC/VTOR/USART1/PC13读回；原始UART四行与board_result1 | 串口电平/9600、HSI实际频率、LED接线/现象、无意外Fault |
| B2 | 已有4次高任务/8次低任务，约46自然Tick，SVC启动与PendSV探针R4～R11、PSP/MSP/CONTROL/EXC_RETURN；高任务在低任务give返回前抢占；Idle断点 | 100Hz周期用外部仪器/DWT测量；两个不同级任务不能证明同级RR |
| B3 | Queue先有限超时再成功交付，Semaphore通知/超时，Mutex持有/单层PI7/恢复2，消息与许可最终0、owner/等待头NULL，有限结束 | 原B3只有两任务/单层PI，不覆盖传递链或外部IRQ交付；不能虚称覆盖 |
| B4 | 8轮Cancel→再次等待→STOP→正常退出，16代worker完成；最终PendSV后复用、旧句柄STALE、新STOP=false；TCB/队列/期限状态检查 | 实机核对每一代/双索引/无旧buffer/guard；不得以输出PASS替代 |

每层宿主等待上限建议30秒作为实验终止看护上限（不是实时性阈值）；超时即停止自动验收，
先保存UART和现场，由获准操作员按恢复计划处理。不可由脚本无限reset重试或扩大擦写范围。
逻辑Tick阈值不能代替墙钟看护，因为SysTick可能不工作。所有终止/暂停动作本身仍需授权。

完整B2/B3硬件验收还须独立的补充场景，当前未部署、不改冻结B1～B4：
1. 同级RR：两同级计算任务、第三监督任务，观察有限时间片/计数，真实SysTick与PendSV，非主动yield伪装。
2. 传递式PI：High7→Mid3→Low1的两锁链，先建立链再释放gate，核对三者effective与owner，
   高任务获锁及所有者合法unlock后恢复base，终态所有owner/等待索引为空。
3. IRQ IPC：获准后使用已审查定时器外部IRQ一次触发Queue ISR send/Sem ISR give，核对IPSR、
   PRIMASK保持和异常返回后的PendSV；不使用IRQ Mutex unlock，输出只在线程。
这些项目在QEMU历史基线有证据，但STM32尚未验证；未来需单独批准相应实验固件与GPIO/IRQ资源。

原始证据：UART原始字节+时间戳（串口工具不得隐式控制DTR/RTS reset）、GDB原始会话、
SCB CFSR/HFSR/ICSR/SHPR、RCC/VTOR、TCB slot/generation/stack guard、MSP水位及业务计数。
测量成本按Stage8.3实时计划校正，阈值由应用要求确定；不把QEMU主机耗时当MCU时延。
任何stack guard损坏、双索引不一致、意外owner/消息重复或异常返回错误均为BLOCKED。

# Fault and emergency-stack boundary

The standalone vector uses the original Default_Handler fatal observation path; no hidden
HardFault replacement or semihost exit. It records IPSR and halts with board_result; it does not
promise PC/frame capture from damaged stacks. No separate emergency stack is allocated in the
standalone images, so its cost is0B and it is NOT available as hardware protection.

Stage8.3's independent QEMU fixture (rerun here in both optimizations/Trace states) uses a no-push
entry, switches to a separate512B emergency stack, captures72B records and validates trusted
frame ranges/EXC_RETURN/stacking errors. Its C-chain bounds128B Debug/80B O2 remain frozen;
GDB verifies original MSP/PSP, masks, UDF escalation, PC/LR/xPSR/CFSR/HFSR, guard and emergency MSP.
This is a tested software design, not STM32 fault injection. It is never linked into standalone.
Deploying it later requires separate vector review and actual emergency+record SRAM reservation;
do not draw from the historical308B MSP margin. Fault before usable stacking may lock up before
software runs; fail-stop/debug capture and controlled restoration are required, no automatic retry.
Trace does not log Fault entry; no UART/IPC/PI/formatting is introduced into Fault paths.

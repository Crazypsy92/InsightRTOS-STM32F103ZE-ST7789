# Standalone stack review

| Opt/Trace/mode | startup MSP B | normal IRQ MSP B | task PSP B | Idle PSP B |
| --- | ---: | ---: | ---: | ---: |
| debug-off-b1 | 228 | 480 | 68 | 68 |
| debug-off-b2 | 308 | 480 | 428 | 88 |
| debug-off-b3 | 308 | 480 | 468 | 88 |
| debug-off-b4 | 308 | 480 | 484 | 88 |
| debug-on-b1 | 444 | 512 | 68 | 68 |
| debug-on-b2 | 308 | 512 | 468 | 88 |
| debug-on-b3 | 308 | 512 | 468 | 88 |
| debug-on-b4 | 308 | 512 | 484 | 88 |
| o2-off-b1 | 168 | 280 | 68 | 68 |
| o2-off-b2 | 204 | 280 | 260 | 76 |
| o2-off-b3 | 204 | 280 | 332 | 76 |
| o2-off-b4 | 172 | 280 | 396 | 76 |
| o2-on-b1 | 384 | 408 | 68 | 68 |
| o2-on-b2 | 484 | 408 | 452 | 76 |
| o2-on-b3 | 484 | 408 | 604 | 76 |
| o2-on-b4 | 452 | 408 | 652 | 76 |

All normal bounds fit4KiB MSP,4KiB user PSP and512B Idle. B1 task/IRQ entries describe retained
code bounds, not an executed scheduler. Reset assembly uses no push before MSP paint; SVC0B,
PendSV8B and register probe40B preserve the frozen ABI. .data/.bss loops add no deep call chain.
Full historical legal nesting remains Debug3788/4096B (308B spare), O2 2276/4096B. Frozen kernel,
port, old workloads and shared BSP objects are unchanged and every historical test rerun; these
deep bounds are not replaced by the shallow selftest figures. New standalone enables no external IRQ.
Legacy Queue ISR/nested IRQ and transitive PI full paths remain covered by old tests/reports.
Compiler .su and actual symbol-bounded disassembly include clone mappings and require no missing
frames, cycles or indirect calls. New reset/startup object code matches old equivalent objects.
Static unallocated SRAM is not MSP headroom. Real chip high-water marks/IRQ latency remain unverified.

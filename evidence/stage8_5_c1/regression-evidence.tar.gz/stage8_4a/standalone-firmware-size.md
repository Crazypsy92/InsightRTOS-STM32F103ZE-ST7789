# Actual standalone resources

| Opt/Trace/mode | Flash B | data B | bss B | static SRAM B incl32KiB user stacks | MSP B | remaining SRAM B |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| debug-off-b1 | 24368 | 8 | 1096 | 33872 | 4096 | 27568 |
| debug-off-b2 | 32792 | 8 | 1672 | 34448 | 4096 | 26992 |
| debug-off-b3 | 35664 | 8 | 1672 | 34448 | 4096 | 26992 |
| debug-off-b4 | 35568 | 8 | 1664 | 34440 | 4096 | 27000 |
| debug-on-b1 | 25648 | 8 | 4216 | 36992 | 4096 | 24448 |
| debug-on-b2 | 34072 | 8 | 4760 | 37536 | 4096 | 23904 |
| debug-on-b3 | 36944 | 8 | 4760 | 37536 | 4096 | 23904 |
| debug-on-b4 | 36880 | 8 | 4752 | 37528 | 4096 | 23912 |
| o2-off-b1 | 13112 | 8 | 1096 | 33872 | 4096 | 27568 |
| o2-off-b2 | 20544 | 8 | 1664 | 34440 | 4096 | 27000 |
| o2-off-b3 | 25176 | 8 | 1664 | 34440 | 4096 | 27000 |
| o2-off-b4 | 24496 | 8 | 1664 | 34440 | 4096 | 27000 |
| o2-on-b1 | 14272 | 8 | 4216 | 36992 | 4096 | 24448 |
| o2-on-b2 | 21736 | 8 | 4760 | 37536 | 4096 | 23904 |
| o2-on-b3 | 26368 | 8 | 4760 | 37536 | 4096 | 23904 |
| o2-on-b4 | 25704 | 8 | 4752 | 37528 | 4096 | 23912 |

Flash is reconstructed BIN size from0x08000000; static SRAM ends at __static_ram_end__, remaining =0x2000f000-end after reserving MSP. Not a runtime watermark or additional MSP margin. Trace objects3072+16B; whole-image deltas may also retain identity state/alignment.

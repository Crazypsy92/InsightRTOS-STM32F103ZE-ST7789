# Stage 8.4-A 独立启动设计

仅软件构建，未授权任何实际板卡。当前已有固件板保持
`HARDWARE_INSTALLATION_BLOCKED`。本配置适用于未来明确授权的独立测试板，
不能作为覆盖原有板卡 Flash 起点的许可。

芯片容量与启动条件参考[ST STM32F103ZE数据手册](https://www.st.com/resource/en/datasheet/stm32f103ze.pdf)
和[RM0008启动配置表](https://www.st.com/resource/en/reference_manual/rm0008-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-microcontrollers-stmicroelectronics.pdf)：
独立板必须确认BOOT0=0选择主Flash启动；这只是文档规定，实际板的跳线、电气状态、
芯片身份和容量仍待授权后核实。本轮不改变BOOT引脚或Option Bytes。

新增 `INSIGHT_BOARD=stm32f103ze_standalone`，独立 CMake 图、startup/reset/linker，
向量起点0x08000000、Flash512KiB、SRAM64KiB、MSP顶0x20010000、MSP4KiB，
仍保留8×4096B用户栈。原 `stm32f103ze`、0x08009400 payload图与产物名称不变。
四种profile使用独立目录，目标名称同时带standalone、模式、优化级别、Trace开关。

冷复位入口先屏蔽IRQ，拒绝Handler/非特权入口，建立CONTROL/MSP/PSP/masks，
仅在C帧建立前画MSP及guard，再在startup.c拷贝.data、清.bss，调用原SystemInit。
共享现有受审查的clock/system/UART/LED/timer实现：HSI8MHz，总线无分频，
SystemInit通过独立链接器的__vector_table设置VTOR=0x08000000，外部IRQ禁用，
TIM2仅prepare不start。原BOARD_APP_VECTOR常量未被任何代码读取，不能拿它代替
实际ELF向量及SystemInit反汇编检查。

共享原kernel、Cortex-M3 port/SVC/PendSV/SysTick、B1..B4 selftest.c、平台适配和寄存器探针，
不改其API、ABI、逻辑与测试期望。SVC优先级0、SysTick0x80、PendSV0xff，
PRIGROUP3；USART1外部优先级0xa0、TIM2 0x60。实际实现位数和实机响应仍待验证。
没有创建flash/load/install/debug-server目标。CMake presets仅configure/build，绝不执行设备命令。

不新增QEMU STM32外设模拟。原全量真实Cortex-M3 QEMU回归、B1..B4公共逻辑及
Fault fixture验证仍执行；新启动路径做ELF、反汇编、静态栈和负面链接审查，未声称该
STM32冷启动代码已在实际STM32或兼容QEMU板上运行。

资源必须以每份ELF为准：.data/.bss/user stacks/Trace/MSP逐项检查，PT_LOAD的物理Flash
区间和虚拟SRAM区间分别验证，按p_paddr重建BIN。两套链接脚本都保留各自起点ASSERT。
负面测试只对build目录内的链接脚本副本或fixture对象生效，不改真实镜像。

RAM运行方案仅计算与评估，不生成可执行RAM装载流程。必要下限为Flash代码/常量+
.data/.bss+固定32KiB用户栈+4KiB MSP，另需向量搬移、应急栈和对齐余量。
即使某个B1镜像算术上能放入SRAM，也没有经过验证的RAM链接图/入口，且会覆盖运行状态、
暂停/复位目标并需恢复，不能据此批准；不能缩栈强行安装。

# Actual host inventory — 2026-11-04 Asia/Shanghai

Host-only enumeration was authorized and executed; no probe opened, no SWD, reset/halt/load/run/write.
uname reports Linux7.0.0-42-generic; no Windows command gateway. WSL generation, Windows version,
Windows driver installation/conflicts/exclusive owner and usbipd-win are NOT OBSERVED.
lsusb exited1: libusb initialization -99. /dev/bus/usb is absent (ls exit2), ordinary-user access
cannot be verified. Read-only sysfs inventory contains no visible ST-Link. This establishes absent
device-node exposure in this execution environment, not a physical unplug/driver diagnosis.
OpenOCD0.12.0 is installed (--version only), st-info/ST tool CLI absent. Native Linux usbip exists,
but presence does not prove Windows forwarding. Windows/WSL options are conditional; currently
neither is selectable from here. No chmod/udev/USB attach/driver installation was attempted.

Git status exited128 due unavailable repository metadata at the mount boundary; no branch/clean
claim is made. Baseline-source SHA and old artifact/evidence manifests provide change protection.
Raw outputs: host-enumeration.log; structured inventory below.

{
  "tools": {
    "arm-none-eabi-gcc": "/usr/bin/arm-none-eabi-gcc",
    "gdb-multiarch": "/usr/bin/gdb-multiarch",
    "qemu-system-arm": "/tmp/c1-tools/bin/qemu-system-arm",
    "cmake": "/usr/bin/cmake",
    "ninja": "/home/mythepsy92/.local/bin/ninja",
    "lsusb": "/usr/bin/lsusb",
    "openocd": "/usr/bin/openocd",
    "st-info": null,
    "st-flash": null,
    "STM32_Programmer_CLI": null,
    "powershell.exe": null,
    "cmd.exe": null,
    "wsl.exe": null,
    "usbipd.exe": null,
    "usbip": "/usr/bin/usbip"
  },
  "commands": [
    {
      "args": [
        "git",
        "status",
        "--short"
      ],
      "exit": 128,
      "output": "fatal: not a git repository (or any parent up to mount point /)\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n"
    },
    {
      "args": [
        "uname",
        "-a"
      ],
      "exit": 0,
      "output": "Linux mythepsy92 7.0.0-43-generic #43-Ubuntu SMP PREEMPT_DYNAMIC Fri Oct 23 13:25:25 UTC 2026 x86_64 GNU/Linux\n"
    },
    {
      "args": [
        "id"
      ],
      "exit": 0,
      "output": "uid=1000(mythepsy92) gid=1000(mythepsy92) groups=1000(mythepsy92),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup)\n"
    },
    {
      "args": [
        "lsusb"
      ],
      "exit": 1,
      "output": "unable to initialize libusb: -99\n"
    },
    {
      "args": [
        "ls",
        "-ld",
        "/dev/bus/usb"
      ],
      "exit": 2,
      "output": "ls: cannot access '/dev/bus/usb': No such file or directory\n"
    },
    {
      "args": [
        "openocd",
        "--version"
      ],
      "exit": 0,
      "output": "Open On-Chip Debugger 0.12.0\nLicensed under GNU GPL v2\nFor bug reports, read\n\thttp://openocd.org/doc/doxygen/bugs.html\n"
    }
  ],
  "usb_devices": [
    {
      "sysfs_name": "1-3",
      "idVendor": "214b",
      "idProduct": "7250",
      "product": "USB2.0 HUB",
      "busnum": "1",
      "devnum": "2",
      "authorized": "1"
    },
    {
      "sysfs_name": "1-3.1",
      "idVendor": "05ac",
      "idProduct": "12a8",
      "manufacturer": "Apple Inc.",
      "product": "iPhone",
      "busnum": "1",
      "devnum": "5",
      "authorized": "1"
    },
    {
      "sysfs_name": "1-3.2",
      "idVendor": "0483",
      "idProduct": "3748",
      "manufacturer": "STMicroelectronics",
      "product": "STM32 STLink",
      "busnum": "1",
      "devnum": "6",
      "authorized": "1"
    },
    {
      "sysfs_name": "1-3.4",
      "idVendor": "258a",
      "idProduct": "0060",
      "manufacturer": "SINO WEALTH",
      "product": "Gaming KB",
      "busnum": "1",
      "devnum": "4",
      "authorized": "1"
    },
    {
      "sysfs_name": "1-4",
      "idVendor": "0408",
      "idProduct": "1042",
      "manufacturer": "Quanta",
      "product": "HD Camera",
      "busnum": "1",
      "devnum": "3",
      "authorized": "1"
    },
    {
      "sysfs_name": "2-2",
      "idVendor": "0bda",
      "idProduct": "9210",
      "manufacturer": "Realtek",
      "product": "RTL9210B-CG",
      "busnum": "2",
      "devnum": "2",
      "authorized": "1"
    },
    {
      "sysfs_name": "3-2",
      "idVendor": "8087",
      "idProduct": "0029",
      "busnum": "3",
      "devnum": "2",
      "authorized": "1"
    },
    {
      "sysfs_name": "3-3",
      "idVendor": "27c6",
      "idProduct": "5125",
      "manufacturer": "Shenzhen Goodix Technology Co.,Ltd.",
      "product": "Goodix Fingerprint Device",
      "busnum": "3",
      "devnum": "3",
      "authorized": "1"
    },
    {
      "sysfs_name": "usb1",
      "idVendor": "1d6b",
      "idProduct": "0002",
      "manufacturer": "Linux 7.0.0-43-generic xhci-hcd",
      "product": "xHCI Host Controller",
      "busnum": "1",
      "devnum": "1",
      "authorized": "1"
    },
    {
      "sysfs_name": "usb2",
      "idVendor": "1d6b",
      "idProduct": "0003",
      "manufacturer": "Linux 7.0.0-43-generic xhci-hcd",
      "product": "xHCI Host Controller",
      "busnum": "2",
      "devnum": "1",
      "authorized": "1"
    },
    {
      "sysfs_name": "usb3",
      "idVendor": "1d6b",
      "idProduct": "0002",
      "manufacturer": "Linux 7.0.0-43-generic xhci-hcd",
      "product": "xHCI Host Controller",
      "busnum": "3",
      "devnum": "1",
      "authorized": "1"
    },
    {
      "sysfs_name": "usb4",
      "idVendor": "1d6b",
      "idProduct": "0003",
      "manufacturer": "Linux 7.0.0-43-generic xhci-hcd",
      "product": "xHCI Host Controller",
      "busnum": "4",
      "devnum": "1",
      "authorized": "1"
    }
  ],
  "usb_device_directory_visible": false,
  "usb_device_directory_access": false,
  "windows_commands_available": false,
  "target_session_executed": false
}

# Windows / WSL / Linux USB 接入方案

本轮只执行宿主枚举，不打开ST-Link、不运行带interface/target配置的OpenOCD，
不执行probe firmware更新、SWD会话、reset/halt、load、Flash/Option Bytes操作。
实际环境记录见evidence/stage8_4a/host-enumeration.log与host-environment.json。

当前可见Linux内核7.0.0-42-generic，未提供Windows命令/WSL工具；不能认定为WSL1或WSL2，
更不能从宿主Linux版本推断不可见Windows版本。Windows版本、驱动签名、设备独占、
驱动冲突、usbipd-win服务/版本均NOT OBSERVED。普通用户USB权限也不能在缺设备节点时判为通过。
`lsusb`初始化libusb失败、/dev/bus/usb缺失与当前沙箱设备可见性一致；sysfs仅代表
可见宿主拓扑，不等于设备节点被透传。未见ST-Link VID/product，不能区分未插入、
未透传或其他外层限制，也不能虚构已确认原因。已安装OpenOCD0.12.0，未提供st-info/
STM32_Programmer_CLI；usbip可执行文件存在不等于转发已建立。

方案A（Windows原生）：若实际实验主机是Windows，优先在原生设备管理器确认ST-Link驱动、
设备实例和错误码，用非连接式PnpDevice/CIM/usbipd list记录拓扑，关闭会自动连目标的GUI会话。
优点是省去WSL转发，缺点是本环境不可见，需在获准的宿主中另行核对工具和驱动。
ST官方工具/驱动按[ST-Link工具页面](https://www.st.com/en/development-tools/st-link-slash-v2.html)
核对版本及支持范围；本轮不安装、不更新探针固件、不点击Connect。

方案B（WSL2）：仅当Windows侧`wsl --list --verbose`证明发行版为WSL2且
`usbipd --version`/`usbipd list`实际可用时采用。Microsoft当前说明采用usbipd-win5+，
要求兼容WSL2内核；参考[官方USB指南](https://learn.microsoft.com/en-us/windows/wsl/connect-usb)。
先记录设备busid/VID/PID/序列号、驱动与所有权，后续获准才讨论bind/attach；
转发会改变Windows可访问性，不能在本轮执行。转发后的/dev/bus/usb、用户组/udev ACL、
lsusb结果还需核实，不能靠chmod777或盲目sudo绕过设备隔离。转发成功也不证明SWD连通。

当前结论：无法在当前执行环境选择可操作的Windows/WSL路径；不安装转发、不改udev规则。
如果实际是原生Linux，应在用户明确允许的设备环境确认USB节点暴露和最小访问权限，
不为套用WSL方案而引入usbipd。两条Windows方案保留为条件方案，而非已部署方案。

未来手动只读Windows枚举模板在scripts/hardware/stage8_4a/windows_inventory.ps1，
本轮未执行；只有Get类查询、版本/列表，不包括设备attach或MCU操作。

缺工具时的安装建议（本轮未执行）：原生Ubuntu宿主可用发行版包`usbutils`、
`openocd`和可选`stlink-tools`；QEMU/GCC/GDB/CMake使用项目环境检查列出的开发工具包。
Windows使用ST官方ST-Link驱动/工具安装包；WSL2 USB转发使用Microsoft指南所列usbipd-win。
驱动安装、USB转发与设备权限修改应在可见宿主由用户明确决定，不能把安装工具误作
允许探针连接、升级、reset或Flash访问。`st-info --probe`也不在本轮枚举白名单内。

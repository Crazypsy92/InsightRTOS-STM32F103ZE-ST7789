# Stage 8.4-A acceptance — 2026-11-04 Asia/Shanghai

**SOFTWARE READY · HARDWARE NOT EXECUTED**

This is readiness to request device-specific authorization for a future independent board, not
approval to connect/control/install on an unconfirmed board. Current occupied board remains
**HARDWARE_INSTALLATION_BLOCKED**; actual USB access and a legal device test scope remain blocked.

- Stage8.3 baseline actually rerun before old build configuration edits: OFF1073/1073, ON1082/1082.
  All1045 historic IDs retained; old evidence preserved using backup/restore and SHA validation.
- No new RTOS API/TCB/lifetime/IPC/scheduler/context ABI. Frozen kernel/include/arch/old BSP/apps
  SHA unchanged. Git unavailable (mount boundary), no clean-working-tree claim.
- Added standalone board graph, independent reset/startup/linker, four build presets. Trace defaults
  OFF. Debug/O2 × OFF/ON × B1..B4 gives16 independent reset-origin images. Shared selftest code
  is unchanged. Old16 APP images plus8 minimum/demo BINs are identical and separately named.
- Actual vector, ELF/BIN/MAP, Flash/SRAM/PSP/MSP/Trace and no-heap/no-QEMU audits pass.
  Negative links 128/128 rejected as intended.
  Whole-image remaining SRAM minimum23904B after32KiB user stacks+4KiB MSP; detailed
  per-profile values in standalone-firmware-size.md. Not an MSP margin or measured watermark.
- Full legal nesting historical bound remains Debug3788/4096B/O2 2276/4096B; new standalone
  startup/IRQ/thread roots analyzed separately with .su/readelf/objdump, no overflow.
  Default fault path unchanged; tested emergency512B design is QEMU-only and not deployed.
- Host enumeration: OpenOCD version available, USB nodes absent/libusb error, sysfs no visible
  ST-Link. Windows/WSL state inaccessible; cannot diagnose unseen driver conflicts or claim SWD.
  Conditional Windows-native and WSL2 plans provided, no forwarding or driver changes performed.
- RAM execution rejected: no approved RAM layout/entry/restoration; larger images exceed budget;
  no stack shrinking. Independent Flash image is for a separately identified/authorized test board.
- B1..B4 future bounded process, data capture, authorization and recovery checklist complete.
  Existing B2 lacks same-priority peers and B3 lacks transitive chain/external IRQ; these hardware
  claims require explicitly authorized supplemental experiments, not UART PASS or QEMU substitution.
- No other repository accessed; no target USB/SWD session, reset/halt, RAM load/execute, Flash/Option
  writes or hardware injection. No automatic8.4-B. Software static correctness cannot certify
  physical wiring, clock/UART/LED, actual exception behavior or MCU WCET.

| Trace/profile | Actual pass | New runtime IDs |
| --- | ---: | ---: |
| off-host | 497/497 | 0 |
| off-arm | 288/288 | 0 |
| off-arm-opt | 288/288 | 0 |
| on-host | 504/504 | 0 |
| on-arm | 289/289 | 0 |
| on-arm-opt | 289/289 | 0 |

There are no new runtime test IDs; this stage reuses frozen B1..B4 and all regressions. Offline
checks add16 independent image audits and128 actual negative link instances, not inflated runtime counts.

Build: source /tmp/insightrtos-tools/env.sh when using the restored temporary tools;
bash scripts/test_stage8_4a.sh. Standalone presets are configure/build-only. Original Stage8.3
driver and historical evidence are not invoked as writers by final regression.

# Standalone linker and startup validation

Independent origin0x08000000/512KiB Flash; APP profile remains0x08009400 through0x08044800.
76 vectors/304B/1024B alignment, initial MSP0x20010000, Thumb Reset/ELF entry, all60 external
vector identities, SVC/PendSV/SysTick entries checked. Explicit LOAD segments independently bound
virtual SRAM and physical Flash; BIN rebuilt from p_paddr is byte-exact. .data LMA/start/end,
.bss start/end,32KiB user stacks,4KiB MSP, Trace disjointness and no unresolved heap/test/QEMU
symbols checked. No BKPT/semihost in STM32 images. VTOR uses __vector_table (actual ELF origin),
not the unused old BOARD_APP_VECTOR macro. HSI8MHz/100Hz, SVC0/SysTick0x80/PendSV0xff,
PRIGROUP3 and external USART1 0xa0/TIM2 0x60 are inherited through unchanged compiled code;
TIM2 prepare does not enable interrupts. Shared object code is checked, not merely comments.

16 images each undergo8 actual rejected links: Flash overflow, SRAM overflow, wrong origin,
misaligned vector, invalid initial MSP, reduced MSP budget, MSP overlap, vector length. Scripts
are temporary build copies; real BIN hash checked after each suite. All old16 APP selftests and
8 minimum/demo profile BINs compared byte-for-byte. No target install/load/flash CMake action.

{
  "configurations": 4,
  "images": 16,
  "cases_per_image": 8,
  "expected_rejections": 128
}
PASS 904 allocatable code/data sections identical between standalone and payload objects; frozen kernel/ABI/old BSP/app SHA unchanged; all16 APP selftest BINs and8 old minimal/demo BINs identical; old evidence SHA unchanged.
